package com.example.manoanu.simpletodo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class EditItemActivity extends AppCompatActivity {
    private int temp = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);
        String value = getIntent().getStringExtra("listdata");
        int pos = getIntent().getIntExtra("position",0);
        temp = pos;
        //System.out.println(" Postion value here" + pos);
        EditText etNewItem = (EditText) findViewById(R.id.edititemswords);
        etNewItem.setText(value);
    }
    public void onSubmit(View view) {
        EditText etName = (EditText) findViewById(R.id.edititemswords);
        // Prepare data intent
        Intent data = new Intent();
        // Pass relevant data back as a result
        data.putExtra("name", etName.getText().toString());
        data.putExtra("code", 200);
        data.putExtra("position", temp);// ints work too
        // Activity finished ok, return the data
        //System.out.println("Position on second screen"+ temp);

        setResult(RESULT_OK, data); // set result code and bundle data for response
        finish(); // closes the activity, pass data to parent
    }
}
